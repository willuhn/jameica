/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

#ifndef INC_os_H
#define INC_os_H

#define WINVER 0x0500
#define _WIN32_IE 0x0500

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN

#include <windows.h>
#include <winuser.h>
#include <commctrl.h>
#include <commdlg.h>
#include <oaidl.h>
#include <shlobj.h>
#include <ole2.h>
#include <olectl.h>
#include <objbase.h>
#include <shlwapi.h>
#include <shellapi.h>

#ifndef _WIN32_WCE
#include <initguid.h>
#include <oleacc.h>
#endif // _WIN32_WCE

#if defined(WIN32_PLATFORM_PSPC) || defined(WIN32_PLATFORM_WFSP)
#include <aygshell.h>
#endif // WIN32_PLATFORM_PSPC, WIN32_PLATFORM_WFSP

#ifdef WIN32_PLATFORM_WFSP
#include <tpcshell.h>
#endif /* WIN32_PLATFORM_WFSP */

/* Optional custom definitions to exclude some types */
#include "defines.h"

/* Structs excludes */
#ifdef _WIN32_WCE
#define NO_BROWSEINFO
#define NO_CHOOSEFONT
#define NO_COMBOBOXINFO
#define NO_DOCINFO
#define NO_GCP_RESULTS
#define NO_GRADIENT_RECT
#define NO_HELPINFO
#define NO_MENUINFO
#define NO_NMREBARCHEVRON
#define NO_NMTTDISPINFO
#define NO_NMTTDISPINFOA
#define NO_NMTTDISPINFOW
#define NO_NONCLIENTMETRICS
#define NO_NONCLIENTMETRICSA
#define NO_NONCLIENTMETRICSW
#define NO_PRINTDLG
#define NO_TOOLINFO
#define NO_TRACKMOUSEEVENT
#define NO_TRIVERTEX
#define NO_WINDOWPLACEMENT
#define NO_DROPFILES
#define NO_MONITORINFO
#define NO_OLECMD
#define NO_OLECMDTEXT

/* OLE */
#define NO_CAUUID
#define NO_CONTROLINFO
#define NO_COSERVERINFO
#define NO_DISPPARAMS
#define NO_DVTARGETDEVICE
#define NO_EXCEPINFO
#define NO_FORMATETC
#define NO_FUNCDESC1
#define NO_FUNCDESC2
#define NO_GUID
#define NO_LICINFO
#define NO_OLEINPLACEFRAMEINFO
#define NO_STATSTG
#define NO_STGMEDIUM
#define NO_TYPEATTR
#define NO_VARDESC1
#define NO_VARDESC2
#endif /* _WIN32_WCE */

#if !defined(WIN32_PLATFORM_PSPC) && !defined(WIN32_PLATFORM_WFSP)
#define NO_SHMENUBARINFO
#endif /* WIN32_PLATFORM_PSPC, WIN32_PLATFORM_WFSP */

#ifndef WIN32_PLATFORM_PSPC
#define NO_SHACTIVATEINFO
#define NO_SHRGINFO
#define NO_SIPINFO
#endif /* WIN32_PLATFORM_PSPC */

/* Functions excludes */
#ifdef _WIN32_WCE
#define NO_AbortDoc
#define NO_ActivateKeyboardLayout
#define NO_Arc
#define NO_CallNextHookEx
#define NO_CallWindowProcA
#define NO_CharLowerA
#define NO_CharUpperA
#define NO_ChooseColorA
#define NO_ChooseFontA
#define NO_ChooseFontW
#define NO_CopyImage
#define NO_CreateAcceleratorTableA
#define NO_CreateCursor
#define NO_CreateDCA
#define NO_CreateFontIndirectA__Lorg_eclipse_swt_internal_win32_LOGFONTA_2
#define NO_CreateFontIndirectA__I
#define NO_CreatePolygonRgn
#define NO_CreateStreamOnHGlobal
#define NO_CreateWindowExA
#define NO_DefFrameProcA
#define NO_DefFrameProcW
#define NO_DefMDIChildProcA
#define NO_DefMDIChildProcW
#define NO_DefWindowProcA
#define NO_DestroyCursor
#define NO_DispatchMessageA
#define NO_DragDetect
#define NO_DragFinish
#define NO_DragQueryFileA
#define NO_DragQueryFileW
#define NO_DrawStateA
#define NO_DrawStateW
#define NO_DrawTextA
#define NO_EnableScrollBar
#define NO_EndDoc
#define NO_EndPage
#define NO_EnumDisplayMonitors
#define NO_EnumFontFamiliesA
#define NO_EnumSystemLanguageGroupsA
#define NO_EnumSystemLanguageGroupsW
#define NO_EnumSystemLocalesA
#define NO_ExpandEnvironmentStringsW
#define NO_ExpandEnvironmentStringsA
#define NO_ExtTextOutA
#define NO_ExtractIconExA
#define NO_FindWindowA
#define NO_GetCharABCWidthsA
#define NO_GetCharABCWidthsW
#define NO_GetCharWidthA
#define NO_GetCharWidthW
#define NO_GetCharacterPlacementA
#define NO_GetCharacterPlacementW
#define NO_GetClassInfoA
#define NO_GetClipboardFormatNameA
#define NO_GetComboBoxInfo
#define NO_GetDIBColorTable
#define NO_GetDIBits
#define NO_GetFontLanguageInfo
#define NO_GetIconInfo
#define NO_GetKeyboardLayout
#define NO_GetKeyboardLayoutList
#define NO_GetKeyboardState
#define NO_GetKeyNameTextA
#define NO_GetKeyNameTextW
#define NO_GetLastActivePopup
#define NO_GetLayout
#define NO_GetLocaleInfoA
#define NO_GetMenu
#define NO_GetMenuDefaultItem
#define NO_GetMenuInfo
#define NO_GetMenuItemCount
#define NO_GetMenuItemInfoA
#define NO_GetMessageA
#define NO_GetMessageTime
#define NO_GetModuleHandleA
#define NO_GetMonitorInfoA
#define NO_GetMonitorInfoW
#define NO_GetObjectA__IILorg_eclipse_swt_internal_win32_LOGPEN_2
#define NO_GetObjectA__IILorg_eclipse_swt_internal_win32_LOGFONTA_2
#define NO_GetObjectA__IILorg_eclipse_swt_internal_win32_LOGBRUSH_2
#define NO_GetObjectA__IILorg_eclipse_swt_internal_win32_DIBSECTION_2
#define NO_GetObjectA__IILorg_eclipse_swt_internal_win32_BITMAP_2
#define NO_GetOpenFileNameA
#define NO_GetProfileStringA
#define NO_GetProfileStringW
#define NO_GetROP2
#define NO_GetSaveFileNameA
#define NO_GetTextCharset
#define NO_GetTextExtentPoint32A
#define NO_GetTextMetricsA
#define NO_GetVersionExA
#define NO_GetWindowLongA
#define NO_GetWindowPlacement
#define NO_GetWindowTextA
#define NO_GetWindowTextLengthA
#define NO_GradientFill
#define NO_ImmGetCompositionFontA
#define NO_ImmGetCompositionStringA
#define NO_ImmSetCompositionFontA
#define NO_InsertMenuA
#define NO_InsertMenuItemA
#define NO_InsertMenuItemW
#define NO_InvalidateRgn
#define NO_IsIconic
#define NO_IsZoomed
#define NO_LineTo
#define NO_LoadBitmapA
#define NO_LoadCursorA
#define NO_LoadIconA
#define NO_LoadImageA
#define NO_LoadLibraryA
#define NO_MapVirtualKeyA
#define NO_MessageBoxA
#define NO_MonitorFromWindow
#define NO_MoveMemory__ILorg_eclipse_swt_internal_win32_DROPFILES_2I
#define NO_MoveMemory__Lorg_eclipse_swt_internal_win32_NMREBARCHEVRON_2II
#define NO_MoveMemory__Lorg_eclipse_swt_internal_win32_HELPINFO_2II
#define NO_MoveMemory__ILorg_eclipse_swt_internal_win32_TRIVERTEX_2I
#define NO_MoveMemory__ILorg_eclipse_swt_internal_win32_GRADIENT_1RECT_2I
#define NO_MoveMemory__Lorg_eclipse_swt_internal_win32_NMTTDISPINFOA_2II
#define NO_MoveMemory__Lorg_eclipse_swt_internal_win32_NMTTDISPINFOW_2II
#define NO_MoveMemory__ILorg_eclipse_swt_internal_win32_NMTTDISPINFOA_2I
#define NO_MoveMemory__ILorg_eclipse_swt_internal_win32_NMTTDISPINFOW_2I
#define NO_MoveMemory__Lorg_eclipse_swt_internal_win32_LOGFONTA_2II
#define NO_MoveMemory__ILorg_eclipse_swt_internal_win32_LOGFONTA_2I
#define NO_MoveToEx
#define NO_OleInitialize
#define NO_OleUninitialize
#define NO_PeekMessageA
#define NO_Pie
#define NO_PostMessageA
#define NO_PostThreadMessageA
#define NO_PrintDlgA
#define NO_PrintDlgW
#define NO_RedrawWindow
#define NO_RegEnumKeyExA
#define NO_RegOpenKeyExA
#define NO_RegQueryInfoKeyA
#define NO_RegQueryValueExA
#define NO_RegisterClassA
#define NO_RegisterClipboardFormatA
#define NO_SetLayout
#define NO_SHBrowseForFolderA
#define NO_SHBrowseForFolderW
#define NO_SHGetPathFromIDListA
#define NO_SHGetPathFromIDListW
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TVITEM_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TVINSERTSTRUCT_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TVHITTESTINFO_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TOOLINFO_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TCITEM_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TBBUTTONINFO_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_TBBUTTON_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_RECT_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_REBARBANDINFO_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_LVITEM_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_LVHITTESTINFO_2
#define NO_SendMessageA__IIILorg_eclipse_swt_internal_win32_LVCOLUMN_2
#define NO_SendMessageA__IIII
#define NO_SendMessageA__III_3S
#define NO_SendMessageA__III_3I
#define NO_SendMessageA__III_3B
#define NO_SendMessageA__II_3II
#define NO_SendMessageA__II_3I_3I
#define NO_SendMessageW__IIILorg_eclipse_swt_internal_win32_TOOLINFO_2
#define NO_SetDIBColorTable
#define NO_SetErrorMode
#define NO_SetMenu
#define NO_SetMenuDefaultItem
#define NO_SetMenuInfo
#define NO_SetMenuItemInfoA
#define NO_SetStretchBltMode
#define NO_SetTextAlign
#define NO_SetWindowLongA
#define NO_SetWindowPlacement
#define NO_SetWindowTextA
#define NO_SetWindowsHookExA
#define NO_SetWindowsHookExW
#define NO_ShellExecuteExA
#define NO_ShowOwnedPopups
#define NO_ShowScrollBar
#define NO_StartDocA
#define NO_StartDocW
#define NO_StartPage
#define NO_SystemParametersInfoA__IILorg_eclipse_swt_internal_win32_RECT_2I
#define NO_SystemParametersInfoA__IILorg_eclipse_swt_internal_win32_NONCLIENTMETRICSA_2I
#define NO_SystemParametersInfoA__II_3II
#define NO_SystemParametersInfoW__IILorg_eclipse_swt_internal_win32_NONCLIENTMETRICSW_2I
#define NO_ToAscii
#define NO_ToUnicode
#define NO_TrackMouseEvent
#define NO_TranslateAcceleratorA
#define NO_TranslateMDISysAccel
#define NO_UnhookWindowsHookEx
#define NO_UnregisterClassA
#define NO_VkKeyScanA
#define NO_VkKeyScanW
#define NO_WaitMessage
#define NO_WindowFromDC

#define ChooseColorW ChooseColor
#define CHOOSECOLORW CHOOSECOLOR
#define LPCHOOSECOLORW LPCHOOSECOLOR
#define FONTENUMPROCW FONTENUMPROC
#define ShellExecuteExW ShellExecuteEx
#define LPSHELLEXECUTEINFOW LPSHELLEXECUTEINFO
#endif /* _WIN32_WCE */

#ifndef WIN32_PLATFORM_HPC2000
#define NO_CommandBar_1AddAdornments
#define NO_CommandBar_1Create
#define NO_CommandBar_1DrawMenuBar
#define NO_CommandBar_1Height
#define NO_CommandBar_1InsertMenubarEx
#define NO_CommandBar_1Show
#endif /* WIN32_PLATFORM_HPC2000 */

#if !defined(WIN32_PLATFORM_PSPC) && !defined(WIN32_PLATFORM_WFSP)
#define NO_SHCreateMenuBar
#define NO_SHSetAppKeyWndAssoc
#endif /* WIN32_PLATFORM_PSPC, WIN32_PLATFORM_WFSP */

#ifdef WIN32_PLATFORM_WFSP
#define NO_CommDlgExtendedError
#define NO_ChooseColorW
#endif /* WIN32_PLATFORM_WFSP */

#ifndef WIN32_PLATFORM_PSPC
#define NO_MoveMemory__Lorg_eclipse_swt_internal_win32_NMRGINFO_2II
#define NO_NMRGINFO
#define NO_SHHandleWMSettingChange
#define NO_SHRecognizeGesture
#define NO_SHSipPreference
#define NO_SipGetInfo
#endif /* WIN32_PLATFORM_PSPC */

#ifndef WIN32_PLATFORM_WFSP
#define NO_SHSendBackToFocusWindow
#endif /* WIN32_PLATFORM_WFSP */

#ifndef _WIN32_WCE
#define NO_CommandBar_1Destroy
#define NO_TransparentImage
#endif /* _WIN32_WCE */

#define TrackMouseEvent _TrackMouseEvent

#define NATIVE_ENTER(env,clazz,func)
#define NATIVE_EXIT(env,clazz,func)

#endif /* INC_os_H */

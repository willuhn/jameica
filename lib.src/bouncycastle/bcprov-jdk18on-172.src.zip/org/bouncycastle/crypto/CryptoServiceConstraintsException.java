package org.bouncycastle.crypto;

public class CryptoServiceConstraintsException
    extends RuntimeException
{
    public CryptoServiceConstraintsException(String msg)
    {
        super(msg);
    }
}

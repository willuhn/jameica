package org.bouncycastle.crypto;

public interface CryptoServicesConstraints
{
    void check(CryptoServiceProperties service);
}

package org.bouncycastle.oer.its.ieee1609dot2.basetypes;

/**
 * Marker for Geographic Region types.
 */
public interface RegionInterface
{
}
